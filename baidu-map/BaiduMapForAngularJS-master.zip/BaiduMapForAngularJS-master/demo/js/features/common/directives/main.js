import highlight from './highlight';
import swipe from './swipe';

export default [highlight, swipe];
