import map from './mapScriptConfig';
import router from './routerConfig';

export default [map, router];
