export default [
    {
        id: 'quickstart',
        isDefault: false,
        when: '/quickstart',
        template: '<quickstart></quickstart>'
    }
];
