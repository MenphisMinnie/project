export default [
    {
        id: 'apidoc',
        isDefault: false,
        when: '/apidoc',
        template: '<apidoc></apidoc>'
    }
];
