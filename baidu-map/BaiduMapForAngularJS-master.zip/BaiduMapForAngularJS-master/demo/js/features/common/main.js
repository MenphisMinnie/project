import components from './components/main';
import directives from './directives/main';

export default [...components, ...directives];
