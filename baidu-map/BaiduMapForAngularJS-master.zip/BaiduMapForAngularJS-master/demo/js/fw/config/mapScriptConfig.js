
export default {
    type: 'configure',
    config(mapScriptServiceProvider) {
        'ngInject';

        mapScriptServiceProvider.setKey('gd0GyxGUxSCoAbmdyQBhyhrZ');
    }
};
