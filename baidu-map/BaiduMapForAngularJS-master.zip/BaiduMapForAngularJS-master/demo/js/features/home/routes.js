export default [
    {
        id: 'home',
        isDefault: true,
        when: '/home',
        template: '<home></home>'
    }
];
