import 'angular-route';
import 'highlight.js';
import 'highlight.js/styles/darcula.css';
import {ngBaiduMap} from '../../../../src';

export default ['ngRoute', ngBaiduMap];
