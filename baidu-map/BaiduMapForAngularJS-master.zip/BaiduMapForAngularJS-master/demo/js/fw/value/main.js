
import routes from './routesValue';

export default [routes];
